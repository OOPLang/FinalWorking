import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;

public class DisplayRoomsWindow extends JFrame{
    JFrame DisplayRoomsFrame;
    JLabel roomLabel1, roomLabel2, roomLabel3, roomLabel4, roomLabel5;
    
    public DisplayRoomsWindow(String roomType, Hotel hotelName){
        DisplayRoomsFrame = new JFrame("Showing Rooms");
        DisplayRoomsFrame.setSize(500,800);
        DisplayRoomsFrame.getContentPane();
        DisplayRoomsFrame.setLayout(new BorderLayout(10, 20));
        DisplayRoomsFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        DisplayRoomsFrame.setBounds(1000,100, 550,400);
        DisplayRoomsFrame.setLayout(null);
        DisplayRoomsFrame.setResizable(false);
        DisplayRoomsFrame.setVisible(true);
        
        if (roomType == "Guest"){
            String table = displayGuestRooms(hotelName.guestRooms);
            table = "GUEST ROOMS\nRoom Number | Capacity | Sqm | Availability\n"+table;
            JOptionPane.showMessageDialog(null, table);
        }else if (roomType == "Suite"){
            String table = displaySuiteRooms(hotelName.suiteRooms);
            table = "SUITE ROOMS\nRoom Number | Kitchen | Capacity | Sqm | Availability\n"+table;
            JOptionPane.showMessageDialog(null, table);
        }else if (roomType == "Executive"){
            String table = displayExecutiveRooms(hotelName.executiveRooms);
            table = "EXECUTIVE ROOMS\nRoom Number | Lounge | Balcony | Capacity | Sqm | Availability\n"+table;
            JOptionPane.showMessageDialog(null, table);
        }
    }

    public static void main(String[] args){
        Hotel ivory = new Hotel();
        DisplayRoomsWindow frame = new DisplayRoomsWindow("Suite", ivory);
    }
    
    public static String displayGuestRooms(ArrayList<Room> arrList){
        ArrayList<String[]> table = new ArrayList<String[]>();
        String big = "";
        System.out.println("GUEST ROOMS\nRoom Number | Capacity | Sqm | Availability");
        for (int idx = 0; idx < arrList.size(); idx++){
            int roomNumber = arrList.get(idx).roomNumber;
            int roomCapacity = arrList.get(idx).roomCapacity;
            int size = arrList.get(idx).size;
            boolean available = arrList.get(idx).available;
            String row = roomNumber+"\t|\t"+roomCapacity+"\t|\t"+size+"\t|\t"+available;
            String[] innertable = {String.valueOf(roomNumber), String.valueOf(roomCapacity), String.valueOf(size), String.valueOf(available)};
            big = big+"\n"+row;
        }
        return big;
    }
    
    public static String displaySuiteRooms(ArrayList<Suite> arrList){
        ArrayList<String[]> table = new ArrayList<String[]>();
        String big = "";
        System.out.println("SUITE ROOMS\nRoom Number | Kitchen | Capacity | Sqm | Availability");
        for (int idx = 0; idx < arrList.size(); idx++){
            int roomNumber = arrList.get(idx).roomNumber;
            String kitchen = arrList.get(idx).kitchen;
            int roomCapacity = arrList.get(idx).roomCapacity;
            int size = arrList.get(idx).size;
            boolean available = arrList.get(idx).available;
            String row = roomNumber+"\t|\t"+kitchen+"\t|\t"+roomCapacity+"\t|\t"+size+"\t|\t"+available;
            String[] innertable = {String.valueOf(roomNumber), kitchen, String.valueOf(roomCapacity), String.valueOf(size), String.valueOf(available)};
            big = big+"\n"+row;
        }
        return big;
    }
    
    public static String displayExecutiveRooms(ArrayList<Executive> arrList){
        ArrayList<String[]> table = new ArrayList<String[]>();
        String big = "";
        System.out.println("EXECUTIVE ROOMS\nRoom Number | Lounge | Balcony | Capacity | Sqm | Availability");
        for (int idx = 0; idx < arrList.size(); idx++){
            int roomNumber = arrList.get(idx).roomNumber;
            String lounge = arrList.get(idx).lounge;
            String balcony = arrList.get(idx).balcony;
            int roomCapacity = arrList.get(idx).roomCapacity;
            int size = arrList.get(idx).size;
            boolean available = arrList.get(idx).available;
            String row = roomNumber+"\t|\t"+lounge+"\t|\t"+balcony+"\t|\t"+roomCapacity+"\t|\t"+size+"\t|\t"+available;
            String[] innertable = {String.valueOf(roomNumber), lounge, balcony, String.valueOf(roomCapacity), String.valueOf(size), String.valueOf(available)};
            big = big+"\n"+row;
        }
        return big;
    }
}