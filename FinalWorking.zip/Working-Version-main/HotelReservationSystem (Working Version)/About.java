import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class About extends JFrame{

    public static void main(String [] args){
        new About().show();
    }

    JPanel bgPanel = new JPanel();


    JLabel img1 = new JLabel();
    ImageIcon image1 = new ImageIcon("AboutUs.png");
   


    public About(){
        setTitle("About Us");
        

        bgPanel.setBounds(0,0,1080,1080);
        
        img1.setText("");
        img1.setIcon(image1);
        img1.setBounds(0,0,1080,1080);


        bgPanel.add(img1);
        add(bgPanel);
        setLayout(null);
        setSize(1080,1080);
        setVisible(true);
    }


}
