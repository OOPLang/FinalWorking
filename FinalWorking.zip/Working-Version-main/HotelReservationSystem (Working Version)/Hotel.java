import java.util.ArrayList;
import javax.swing.*;

public class Hotel {
    ArrayList<Room> guestRooms = new ArrayList<Room>();
    ArrayList<Suite> suiteRooms = new ArrayList<Suite>();
    ArrayList<Executive> executiveRooms = new ArrayList<Executive>();
    
    public Hotel(){
        //int roomNumber, int roomCapacity, int size(sqm), boolean available
        Room guestroom1 = new Room(101, 2, 30, true);
        Room guestroom2 = new Room(142, 4, 35, false);
        Room guestroom3 = new Room(103, 2, 30, true);
        
        guestRooms.add(0, guestroom1);
        guestRooms.add(1, guestroom2);
        guestRooms.add(2, guestroom3);
        
        //Suite(String kitchen, int roomNumber, int roomCapacity, int size, boolean available)
        Suite suiteroom1 = new Suite("Mini", 259, 4, 50, true);
        Suite suiteroom2 = new Suite("Full", 231, 2, 50, false);
        Suite suiteroom3 = new Suite("Mini", 252, 4, 50, false);
        
        suiteRooms.add(0, suiteroom1);
        suiteRooms.add(1, suiteroom2);
        suiteRooms.add(2, suiteroom3);
        
        //Executive(String lounge, String balcony, int roomNumber, int roomCapacity, int size, boolean available)
        Executive executiveRoom1 = new Executive("VIP", "Beach View", 340, 2, 80, true);
        Executive executiveRoom2 = new Executive("Basic", "Pool View", 312, 6, 80, true);
        Executive executiveRoom3 = new Executive("VIP", "Beach View", 302, 2, 80, true);
        
        executiveRooms.add(0, executiveRoom1);
        executiveRooms.add(1, executiveRoom2);
        executiveRooms.add(2, executiveRoom3);        
    }
    
    public void DisplayRoomsWindow(String roomType, Hotel hotelName){
        if (roomType == "Guest"){
            String table = displayGuestRooms(hotelName.guestRooms);
            table = "GUEST ROOMS\nRoom Number | Capacity | Sqm | Availability\n"+table;
            JOptionPane.showMessageDialog(null, table);
        }else if (roomType == "Suite"){
            String table = displaySuiteRooms(hotelName.suiteRooms);
            table = "SUITE ROOMS\nRoom Number | Kitchen | Capacity | Sqm | Availability\n"+table;
            JOptionPane.showMessageDialog(null, table);
        }else if (roomType == "Executive"){
            String table = displayExecutiveRooms(hotelName.executiveRooms);
            table = "EXECUTIVE ROOMS\nRoom Number | Lounge | Balcony | Capacity | Sqm | Availability\n"+table;
            JOptionPane.showMessageDialog(null, table);
        }
    }
    
    public static String displayGuestRooms(ArrayList<Room> arrList){
        ArrayList<String[]> table = new ArrayList<String[]>();
        String big = "";
        System.out.println("GUEST ROOMS\nRoom Number | Capacity | Sqm | Availability");
        for (int idx = 0; idx < arrList.size(); idx++){
            int roomNumber = arrList.get(idx).roomNumber;
            int roomCapacity = arrList.get(idx).roomCapacity;
            int size = arrList.get(idx).size;
            boolean available = arrList.get(idx).available;
            String row = roomNumber+"\t|\t"+roomCapacity+"\t|\t"+size+"\t|\t"+available;
            String[] innertable = {String.valueOf(roomNumber), String.valueOf(roomCapacity), String.valueOf(size), String.valueOf(available)};
            big = big+"\n"+row;
        }
        return big;
    }
    
    public static String displaySuiteRooms(ArrayList<Suite> arrList){
        ArrayList<String[]> table = new ArrayList<String[]>();
        String big = "";
        System.out.println("SUITE ROOMS\nRoom Number | Kitchen | Capacity | Sqm | Availability");
        for (int idx = 0; idx < arrList.size(); idx++){
            int roomNumber = arrList.get(idx).roomNumber;
            String kitchen = arrList.get(idx).kitchen;
            int roomCapacity = arrList.get(idx).roomCapacity;
            int size = arrList.get(idx).size;
            boolean available = arrList.get(idx).available;
            String row = roomNumber+"\t|\t"+kitchen+"\t|\t"+roomCapacity+"\t|\t"+size+"\t|\t"+available;
            String[] innertable = {String.valueOf(roomNumber), kitchen, String.valueOf(roomCapacity), String.valueOf(size), String.valueOf(available)};
            big = big+"\n"+row;
        }
        return big;
    }
    
    public static String displayExecutiveRooms(ArrayList<Executive> arrList){
        ArrayList<String[]> table = new ArrayList<String[]>();
        String big = "";
        System.out.println("EXECUTIVE ROOMS\nRoom Number | Lounge | Balcony | Capacity | Sqm | Availability");
        for (int idx = 0; idx < arrList.size(); idx++){
            int roomNumber = arrList.get(idx).roomNumber;
            String lounge = arrList.get(idx).lounge;
            String balcony = arrList.get(idx).balcony;
            int roomCapacity = arrList.get(idx).roomCapacity;
            int size = arrList.get(idx).size;
            boolean available = arrList.get(idx).available;
            String row = roomNumber+"\t|\t"+lounge+"\t|\t"+balcony+"\t|\t"+roomCapacity+"\t|\t"+size+"\t|\t"+available;
            String[] innertable = {String.valueOf(roomNumber), lounge, balcony, String.valueOf(roomCapacity), String.valueOf(size), String.valueOf(available)};
            big = big+"\n"+row;
        }
        return big;
    }
}

