public class Test2{
    public static void main(String[] args){
        Hotel ivory = new Hotel();
        ivory.DisplayRoomsWindow("Guest", ivory); 
    }
}