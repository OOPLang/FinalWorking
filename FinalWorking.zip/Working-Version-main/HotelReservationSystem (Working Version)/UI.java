import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.ImageIcon;

public class UI extends JFrame implements ActionListener
{
    //Initialize the assets to be used 
    JFrame frame;
    JPanel panel;
    JButton bookButton;
    JLabel companyLabel, contactLabel,homePage;
    
    Font myFont = new Font("Ink Free",Font.BOLD,20);
    
    public UI(){
        Border blackline = BorderFactory.createLineBorder(Color.black);
        frame = new JFrame();
        panel = new JPanel();
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                exitForm(e);
            }
        });
        
        frame.setTitle("Hotel Reservation System");
        frame.setSize(550, 500);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bookButton = new JButton("Book Now!");
        bookButton.setPreferredSize(new Dimension(100,30));
        companyLabel = new JLabel("ELIS ALIAS HOTEL");
        companyLabel.setFont(myFont);
        ImageIcon image = new ImageIcon("logo.png"); // Application Icon
        frame.setIconImage(image.getImage());
        ImageIcon homePageIcon = new ImageIcon("hotelResImage.jpg");
        //frame.setIconImage(homePageIcon.getImage());
        homePage = new JLabel("Hello");
        homePage.setIcon(homePageIcon);
        
        contactLabel = new JLabel("Contact Us: 0909-9090-0909");
        companyLabel.setBorder(blackline);
        panel.add(companyLabel);
        panel.add(contactLabel);
        panel.setBackground(Color.CYAN);
        panel.setLayout(new FlowLayout(FlowLayout.CENTER,28,5));
        frame.add(panel, BorderLayout.NORTH);
        panel.add(bookButton);

        bookButton.addActionListener(this);
        
        frame.setVisible(true);
        frame.add(homePage);
        
    }
    
    public static void main(String[] args){
        new UI();
    
    }
    
    public void actionPerformed(ActionEvent e){
    
        if(e.getSource() == bookButton){
           frame.dispose();
           new BookingWindow();
           
        
        }
    
    }
    private void exitForm(WindowEvent e){
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f, "Exiting Module");
    }
}
