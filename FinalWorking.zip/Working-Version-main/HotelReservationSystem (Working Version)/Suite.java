public class Suite extends Room {
    String kitchen; //mini or full
   
    public Suite(String kitchen, int roomNumber, int roomCapacity, int size, boolean available){
        super(roomNumber, roomCapacity, size, available);
        this.rate = 3750;
        this.kitchen = kitchen;
    }
}