import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class guestRooms extends JFrame
{
    public static String clickVenueInfo;
    public static int price;
    public static int pax;

    String city[] = {"Guest Room 1", "Guest Room 2", "Guest Room 3", "Guest Room 4", "Guest Room 5"};
    
    public guestRooms()
    {
       

        ImageIcon imageB = new ImageIcon(getClass().getResource("HotelBanner.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(0,-210,1000,800);

        JComboBox choice = new JComboBox(city);
        choice.setFont(new Font("Arial",1,16));
        choice.setForeground(new Color(255,255,255));
        choice.setBackground(new Color(0,0,0));
        choice.setBounds(300,270,260,40);

        JButton select = new JButton("Browse");
        select.setFont(new Font("Arial", 1, 16));
        select.setForeground(new Color(255,255,255));
        select.setBackground(new Color(0,0,0));
        select.setBounds(570,270,100,40);

        JLabel text1 = new JLabel("Experience Your Dreams");
        text1.setFont(new Font("Arial", 1, 25));
        text1.setForeground(new Color(0,0,0));
        text1.setBounds(330,320,800,100);
 
        ImageIcon imagePackage = new ImageIcon(getClass().getResource("GuestRooms.png"));
        JLabel picturePackage = new JLabel(imagePackage);
        picturePackage.setBounds(-5,135,1000,800);
 
        JButton menu = new JButton("Back to Menu");
        menu.setFont(new Font("Arial", 0, 14));
        menu.setForeground(new Color(255,255,255));
        menu.setBackground(new Color(0,0,0));
        menu.setBounds(422,715,150,25);
        

        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);

        JLabel membersName = new JLabel("All Rights Reserved");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(20,705,1000,50);
    

        setTitle("GUEST ROOMS");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        add(text1);
        
        add(membersName);
        
        add(picturePackage);
        add(backgroundBelow);
        add(menu);
        add(select);
        add(choice);
        add(banner);
        
       
       
        menu.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               menu(e);
           }
       });
    }
    
    public void menu(ActionEvent e){
        new UI().show();
        this.dispose();
    }
    public static void main(String[] args){
        new guestRooms().show();
        
    }
}
